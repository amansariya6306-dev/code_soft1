# CodeSoft Internship - Task 1
## Personal Portfolio Website

Files:
- index.html — complete responsive portfolio (HTML + CSS + JavaScript in one file)
- resume.pdf — sample downloadable CV

How to run:
1. Open index.html in Chrome/Edge/Firefox.
2. Replace placeholder email/phone/location.
3. Replace project demo links with your GitHub/live project URLs.
4. Replace resume.pdf with your final CV if needed.

Features:
- Home, About, Skills, Projects, Resume and Contact sections
- Responsive navigation menu
- Smooth scrolling
- Hover animations
- Scroll reveal animation
- Contact form validation
- Downloadable Resume/CV
- Mobile responsive layout
